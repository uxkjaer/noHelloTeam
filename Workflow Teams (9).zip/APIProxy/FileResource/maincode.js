
var zzbody = context.proxyRequest.body.asJSON
print(JSON.stringify(zzbody))
var zzheader = context.proxyRequest
print(zzheader)


